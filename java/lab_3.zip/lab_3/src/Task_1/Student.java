package Task_1;
/*Класс Student должен содержать поля: String firstName, lastName, group. А
также, double averageMark, содержащее среднюю оценку. Создайте переменную
типа Student, которая ссылается на объект типа Magistracy. Создайте метод
getScholarship() для класса Student, который возвращает сумму стипендии. Если
средняя оценка студента равна 8, то сумма 100 руб., иначе 80 руб.*/
public class Student {
    private String firstName, lastName;
    private int group;
    private double averageMark;
    public Student(String firstName, String lastName, int group, double averageMark) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.averageMark = averageMark;
        this.group = group;
    }
    int getScholarship(){
        if (averageMark >= 5) {
            if (averageMark >= 8) {
                return 100;
            } else {
                return 80;
            }
        } else return 0;
    }
    public static void showMas(Student[] mas){
        System.out.println("The students you entered are: ");
        for (int i = 0; i < mas.length; i++) {
            mas[i].show();
        }
    }
    public void show() {
        System.out.println("First name - " + getFirstName() + ", last name - " + getLastName() + ", group - " + getGroup());
        System.out.println("Average mark = " + getAverageMark());
    }

    public void setAverageMark(double averageMark) {
        this.averageMark = averageMark;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public void setGroup(int group) {
        this.group = group;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public double getAverageMark() {
        return averageMark;
    }
    public String getFirstName() {
        return firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public int getGroup() {
        return group;
    }
}
