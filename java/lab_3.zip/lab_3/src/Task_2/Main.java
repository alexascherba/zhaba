package Task_2;

public class Main {
}
