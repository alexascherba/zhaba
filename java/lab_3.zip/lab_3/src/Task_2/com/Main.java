package Task_2.com;

public class Main {
}
