package Task_2.com.company;

import Task_2.com.company.details.Engine;
import Task_2.com.company.professions.Driver;
import Task_2.com.company.vehicles.Car;
import Task_2.com.company.vehicles.Lorry;
import Task_2.com.company.vehicles.SportCar;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        try {
            System.out.println("Водительская характеристика ");
            System.out.print("ФИО ");
            String fullName = reader.nextLine();
            System.out.print("Возраст ");
            int age = reader.nextInt();
            System.out.print("Водительский стаж ");
            int experience = reader.nextInt();
            Driver driver = new Driver(fullName, age, experience);

            System.out.println("Выберите характеристики какой машины вы хотите ввести");
            System.out.println("1 - машина | 2 - грузовик | 3 - спорткар");
            switch(reader.nextInt()){
                case 1:
                    System.out.print("Модель ");
                    String model = reader.next();
                    System.out.print("Класс автомобиля ");
                    String car_class = reader.next();
                    System.out.print("Вес ");
                    int weight = reader.nextInt();
                    System.out.print("Мощность двигателя ");
                    int power = reader.nextInt();
                    System.out.print("Страна производства ");
                    String country = reader.next();
                    Engine engine = new Engine(power, country);
                    Car car = new Car(model, car_class, weight, driver, engine);
                    System.out.println(car);
                    break;
                case 2:
                    System.out.print("Модель ");
                    String model1 = reader.next();
                    System.out.print("Класс автомобиля ");
                    String car_class1 = reader.next();
                    System.out.print("Вес ");
                    int weight1 = reader.nextInt();
                    System.out.print("Грузоподъемность ");
                    int carrying = reader.nextInt();
                    System.out.print("Мощность двигателя ");
                    int power1 = reader.nextInt();
                    System.out.print("Страна производства ");
                    String country1 = reader.next();
                    Engine engine1 = new Engine(power1, country1);
                    Car lorry = new Lorry(model1, car_class1, weight1, driver, engine1, carrying);
                    System.out.println(lorry);
                    break;
                case 3:
                    System.out.print("Модель ");
                    String model2 = reader.next();
                    System.out.print("Класс автомобиля ");
                    String car_class2 = reader.next();
                    System.out.print("Вес ");
                    int weight2 = reader.nextInt();
                    System.out.print("Скорость ");
                    int speed = reader.nextInt();
                    System.out.print("Мощность двигателя ");
                    int power2 = reader.nextInt();
                    System.out.print("Страна производства ");
                    String country2 = reader.next();
                    Engine engine2 = new Engine(power2, country2);
                    Car sportcar = new SportCar(model2, car_class2, weight2, driver, engine2, speed);
                    System.out.println(sportcar);
                    break;
                }
        } catch (InputMismatchException e){
            System.out.println("Wrong input");
        }
    }
}
