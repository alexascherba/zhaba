package Task_2.com.company.vehicles;


import Task_2.com.company.details.Engine;
import Task_2.com.company.professions.Driver;

/*. Класс Car должен содержать поля – марка
автомобиля, класс автомобиля, вес, водитель типа Driver, мотор типа Engine.
Методы start(), stop(), turnRight(), turnLeft(), которые выводят на печать:
"Поехали", "Останавливаемся", "Поворот направо" или "Поворот налево". А
также метод toString(), который выводит полную информацию об автомобиле, ее
водителе и моторе.*/
public class Car {
    private String model;
    private String car_class;
    private int weight;
    private Driver driver;
    private Engine engine;
    public Car(String model, String car_class, int weight, Driver driver, Engine engine){
        this.model = model;
        this.car_class = car_class;
        this.weight = weight;
        this.driver = driver;
        this.engine = engine;
    }
    public void start(){
        System.out.println("Поехали");
    }
    public void stop(){
        System.out.println("Останавливаемся");
    }
    public void turnRight(){
        System.out.println("Поворот направо");
    }
    public void turnLeft(){
        System.out.println("Поворот налево");
    }

    @Override
    public String toString() {
        String info = "Автомобиль " + model + " класса " + car_class +
                "\n" + driver.toString() + engine.toString();
        return info;
    }

    public int getWeight() {
        return weight;
    }

    public Driver getDriver() {
        return driver;
    }

    public String getCar_class() {
        return car_class;
    }

    public Engine getEngine() {
        return engine;
    }

    public void setCar_class(String car_class) {
        this.car_class = car_class;
    }

    public String getModel() {
        return model;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }
}
