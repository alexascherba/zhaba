package Task_2.com.company.vehicles;

import Task_2.com.company.details.Engine;
import Task_2.com.company.professions.Driver;

public class SportCar extends Car{
    private int speed;
    public SportCar (String model, String car_class, int weight, Driver driver, Engine engine, int speed){
        super(model, car_class, weight, driver, engine);
        this.speed = speed;
    }

    @Override
    public String toString() {
        return super.toString() + ", скорость " + speed;
    }

    @Override
    public void setWeight(int weight) {
        super.setWeight(weight);
    }

    @Override
    public void setCar_class(String car_class) {
        super.setCar_class(car_class);
    }

    @Override
    public String getCar_class() {
        return super.getCar_class();
    }

    @Override
    public void setModel(String model) {
        super.setModel(model);
    }

    @Override
    public Engine getEngine() {
        return super.getEngine();
    }

    @Override
    public Driver getDriver() {
        return super.getDriver();
    }

    @Override
    public void setEngine(Engine engine) {
        super.setEngine(engine);
    }

    @Override
    public void setDriver(Driver driver) {
        super.setDriver(driver);
    }

    @Override
    public String getModel() {
        return super.getModel();
    }

    @Override
    public int getWeight() {
        return super.getWeight();
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
}
