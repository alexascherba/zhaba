package Task_3;

public class Apple extends Fruit{
    @Override
    public double price(double weight) {
        return weight * 4.2;
    }

    @Override
    public void printManufacturerInfo() {
        super.printManufacturerInfo();
    }
}
