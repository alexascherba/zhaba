package Task_3;
/*Класс Фрукт должен содержать: поле вес, завершенный метод
printManufacturerInfo(){System.out.print("Made in RB");}, абстрактный метод,
возвращающий стоимость фрукта, который должен быть переопределен в
каждом классе наследнике. Метод должен учитывать вес фрукта. */
public abstract class Fruit {
    private double weight;
    public void printManufacturerInfo(){
        System.out.print("Made in RB");
    }
    public abstract double price(double weight);
}
