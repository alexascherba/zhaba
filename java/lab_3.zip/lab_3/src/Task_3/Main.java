package Task_3;
/*Создайте абстрактный класс Фрукт и классы Яблоко, Груша, Слива
расширяющие его. Класс Фрукт должен содержать: поле вес, завершенный метод
printManufacturerInfo(){System.out.print("Made in RB");}, абстрактный метод,
возвращающий стоимость фрукта, который должен быть переопределен в
каждом классе наследнике. Метод должен учитывать вес фрукта. Создайте
несколько объектов разных классов. Подсчитайте общую стоимость проданных
фруктов. А также общую стоимость отдельно проданных яблок, груш и слив*/
public class Main {
    public static void main(String[] args) {
        Fruit apple = new Apple();
        Fruit plum = new Plum();
        Fruit pear = new Pear();
        Fruit pears = new Pear();
        double sum = apple.price(1.5) + plum.price(0.6) + pears.price(2) + pear.price(0.65);
        System.out.println("Общая стоимость проданных фруктов " + sum);
        System.out.println("Общая стоимость яблок " + apple.price(1.5));
        System.out.println("Общая стоимость груш " + pear.price(0.65) + pears.price(2));
        System.out.println("Общая стоимость слив " + plum.price(0.6));
    }
}
