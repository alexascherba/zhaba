package Task_3;

public class Pear extends Fruit{
    @Override
    public double price(double weight) {
        return weight * 5.0;
    }

    @Override
    public void printManufacturerInfo() {
        System.out.println("Made in Brazil");
    }
}
