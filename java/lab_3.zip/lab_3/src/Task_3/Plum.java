package Task_3;

public class Plum extends Fruit{
    @Override
    public double price(double weight) {
        return weight * 8.1;
    }

    @Override
    public void printManufacturerInfo() {
        System.out.println("Made in PL");
    }
}
