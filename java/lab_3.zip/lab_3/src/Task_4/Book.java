package Task_4;

public class Book implements Printable{
    private String name;
    public Book(String name) {
        this.name = name;
    }
    void printBooks(Printable[] printable){
        for(Printable mas : printable){
            if(mas instanceof Book){
                mas.print();
            }
        }
    }
    @Override
    public void print() {
        System.out.println(name);
    }
}
