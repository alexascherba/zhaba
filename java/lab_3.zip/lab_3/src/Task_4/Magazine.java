package Task_4;

public class Magazine implements Printable{
    private String name;
    public Magazine(String name) {
        this.name = name;
    }
    void printMagazines(Printable[] printable){
        for(Printable mas : printable){
            if(mas instanceof Magazine){
                mas.print();
            }
        }
    }
    @Override
    public void print() {
        System.out.println(name);
    }
}
