package Task_4;

import java.util.InputMismatchException;
import java.util.Scanner;

/*Определите интерфейс Printable, содержащий метод void print().
Определить класс Book, реализующий интерфейс Printable. Определите класс
Magazine, реализующий интерфейс Printable. Создайте массив типа Printable,
который будет содержать книги и журналы. В цикле необходимо пройти по
массиву и вызвать метод print() для каждого объекта. Создайте статический
метод printMagazines(Printable[] printable) в классе Magazine, который будет
выводить на консоль названия только журналов. Создайте статический метод
printBooks(Printable[] printable) в классе Book, который будет выводить на
консоль названия только книг. Используйте оператор instanceof*/
public class Main {
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Введите количество изданий в каталоге ");
        try{
            int n = reader.nextInt();
            Printable[] mas = new Printable[n];
            for (int i = 0; i < n; i++) {
                System.out.println("Выберите тип издания | 1 - журнал | 2 - книга |");
                int choice = reader.nextInt();
                switch(choice){
                    case 1:
                        System.out.println("Введите название журнала");
                        String name1 = reader.next();
                        mas[i] = new Magazine(name1);
                        break;
                    case 2:
                        System.out.println("Введите название книги");
                        String name2 = reader.next();
                        mas[i] = new Book(name2);
                        break;
                }
            }
            System.out.println("Каталог ");
            for (Printable x : mas) {
                x.print();
            }
        } catch(InputMismatchException e){
            System.out.println("Неправильный ввод");
        }



    }
}
