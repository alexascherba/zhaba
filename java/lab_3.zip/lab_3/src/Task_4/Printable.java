package Task_4;

public interface Printable {
    void print();
}
