package Task_5;

import java.util.Scanner;
/*Создайте статический метод, который принимает на вход три параметра:
login, password и confirmPassword. Login должен содержать только латинские
буквы, цифры и знак подчеркивания. Длина login должна быть меньше 20
символов. Если login не соответствует этим требованиям, необходимо выбросить
WrongLoginException. Password должен содержать только латинские буквы,
цифры и знак подчеркивания. Длина password должна быть меньше 20 символов.
Также password и confirmPassword должны быть равны. Если password не
соответствует этим требованиям, необходимо выбросить
WrongPasswordException. WrongPasswordException и WrongLoginException –
пользовательские классы исключения с двумя конструкторами – один по
умолчанию, второй принимает сообщение исключения и передает его в
конструктор класса Exception. Обработка исключений проводится внутри метода.
Необходимо использовать несколько блоков catch. Метод возвращает true, если
значения верны или false в другом случае.*/
public class Main {
    public static boolean checking(String login, String password, String confirmPassword){
        try {
            if (login.length() > 20 || !login.matches("\\w+") || login.matches("[а-яА-Я]")) {
                throw new WrongLoginException("Login is incorrect");
            }
            if (password.length() > 20 || !password.matches("\\w+") || password.matches("[а-яА-Я]")) {
                throw new WrongPasswordException("Password is incorrect");
            }
            if (!password.equals(confirmPassword)) {
                throw new WrongPasswordException("Passwords don't match");
            }
            return true;
        } catch (WrongLoginException e) {
            System.out.println(e);
            return false;
        } catch (WrongPasswordException p) {
            System.out.println(p);
            return false;
        }
    }
    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        System.out.print("Login: ");
        String login = reader.nextLine();
        System.out.println();

        System.out.print("Password: ");
        String password = reader.nextLine();
        System.out.println();

        System.out.print("Confirm your password: ");
        String confirmPassword = reader.nextLine();

        System.out.println();

        if (checking(login, password, confirmPassword)){
            System.out.println("Authorization passed");
        } else {
            System.out.println("Incorrect input");
        }

    }
}
