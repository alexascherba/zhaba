package Task_5;

public class WrongPasswordException extends Exception{
    public WrongPasswordException(String x) {
        super(x);
    }
    public WrongPasswordException() {
        super();
    }

    @Override
    public String toString() {
        return "Incorrect password";
    }
}
